from PySide6 import QtWidgets, QtCore
from PySide6.QtGui import QKeyEvent
from ui_loginUI import *
from ui_mainUI import *
from config import config
import psycopg2

#db connection
def connect():
    connection = None
    try:
        params = config()
        print('Connecting...')
        connection = psycopg2.connect(**params)

        #create cursor

        crsr = connection.cursor()
        print('PostgerSql database version: ')
        crsr.execute('SELECT version()')
        dv_version = crsr.fetchone()
        print(dv_version)
        crsr.close()
    except(Exception, psycopg2.DataError) as error:
        print(error)
    finally:
        if connection is not None:
            connection.close()
            print('DB connection terminated.')



class LoginWindow(QtWidgets.QMainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        self.ui = Ui_LoginWindow()
        self.ui.setupUi(self)
        self.show()

        #LOGIN 
        # ===========================================================================================================================================================================
        
        self.ui.signInBtn.clicked.connect(self.handle_login)
        self.ui.usernameField.installEventFilter(self)
        self.ui.passwordField.installEventFilter(self)

    #Enter key clicked
    # ===========================================================================================================================================================================

    def eventFilter(self, source, event):
        if event.type() == QtCore.QEvent.KeyPress:
            if source == self.ui.usernameField or source == self.ui.passwordField:
                key = event.key()
                if key == QtCore.Qt.Key_Return or key == QtCore.Qt.Key_Enter:
                    self.handle_login()
                else:
                    self.ui.usernameField.setStyleSheet("border: none;")
                    self.ui.passwordField.setStyleSheet("border: none;")

    #Login button key clicked
    # ===========================================================================================================================================================================
    
    def handle_login(self):
        if self.ui.usernameField.text() == 'admin' and self.ui.passwordField.text() == 'adminpass':
            self.close()
            self.main_window = MainWindow()
     
        else:
            self.ui.usernameField.setStyleSheet("border: 1px solid red;")
            self.ui.passwordField.setStyleSheet("border: 1px solid red;")
            

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.show()
        self.prev_page = 1
        
        #TABLE WIDGETS
        # ===========================================================================================================================================================================

        self.ui.mem_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ui.memStat_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ui.transac_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ui.services_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ui.emp_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

        #MENU
        # ===========================================================================================================================================================================

        self.ui.menu_container.setCurrentWidget(self.ui.home_page)
        self.ui.home.setStyleSheet("background-color: rgba(255,255,255,50)")
        self.ui.home.clicked.connect(self.select_home)
        self.ui.mem_list.clicked.connect(self.select_memlist)
        self.ui.mem_status.clicked.connect(self.select_memstat)
        self.ui.transaction.clicked.connect(self.select_transact)
        self.ui.employees.clicked.connect(self.select_employees)
        self.ui.services.clicked.connect(self.service_popup)

        #LOGOUT 
        # ===========================================================================================================================================================================

        self.ui.services_exitbtn.clicked.connect(self.close_service_popup)
        self.ui.logout.clicked.connect(self.logoutpopup)
        self.ui.confLogout_btn.clicked.connect(self.confirm_logout)
        self.ui.cancelLogout_btn.clicked.connect(self.cancel_logout)

        #SERVICES 
        # ===========================================================================================================================================================================

        self.ui.addService_btn.clicked.connect(self.add_service)
        self.ui.addService_cancelbtn.clicked.connect(self.cancel_add_service)
        self.ui.editService_btn.clicked.connect(self.edit_service)
        self.ui.serviceUpdate_cancelbtn.clicked.connect(self.cancel_edit_service)
        
        #RENEW MEMBERSHIP SERVICE
        # ===========================================================================================================================================================================

        self.ui.renew_btn.clicked.connect(self.renew_popup)
        self.ui.renewCancel_btn.clicked.connect(self.cancel_renew)
        self.ui.renewPay_btn.clicked.connect(self.pay_renew)

        #REGISTER MEMBER
        # ===========================================================================================================================================================================

        self.ui.add_member.clicked.connect(self.add_member)
        self.ui.regismem_cancelbtn.clicked.connect(self.regis_cancel)
        self.ui.regismem_savebtn.clicked.connect(self.regis_save)
        self.ui.pay_cancelbtn.clicked.connect(self.cancel_payment)
        self.ui.pay_btn.clicked.connect(self.confirm_payment)

        #DELETE MEMBER
        # ===========================================================================================================================================================================

        self.ui.delete_member.clicked.connect(self.delete_member)
        self.ui.cancelDelete_mem.clicked.connect(self.cancel_delete_mem)
        self.ui.confDelete_mem.clicked.connect(self.confirm_delete_mem)

        #EDIT MEMBER DETAILS
        # ===========================================================================================================================================================================
        
        self.ui.edit_member.clicked.connect(self.edit_member)
        self.ui.mem_cancelbtn.clicked.connect(self.cancel_edit_mem)
        self.ui.mem_savebtn.clicked.connect(self.save_edit_mem)

        #EMPLOYEE
        # ===========================================================================================================================================================================

        self.ui.add_employee.clicked.connect(self.add_employee)
        self.ui.AddEmp_cancelbtn.clicked.connect(self.cancel_add_employee)
        self.ui.edit_employee.clicked.connect(self.edit_employee)
        self.ui.EditEmp_cancelbtn.clicked.connect(self.cancel_edit_employee)

    #Menu bar selection
    # ===========================================================================================================================================================================

    def select_home(self):
        self.ui.menu_container.setCurrentWidget(self.ui.home_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.previous(1)
        
    def select_memlist(self):
        self.ui.menu_container.setCurrentWidget(self.ui.member_list_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.previous(2)
        
    def select_memstat(self):
        self.ui.menu_container.setCurrentWidget(self.ui.member_status_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.previous(3)
    
    def select_transact(self):
        self.ui.menu_container.setCurrentWidget(self.ui.transaction_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.previous(4)
    
    def select_employees(self):
        self.ui.menu_container.setCurrentWidget(self.ui.employees_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.previous(5)

    #Previous Page
    # ===========================================================================================================================================================================

    def previous(self,page):
        self.prev_page = page

    #Show list of services
    # ===========================================================================================================================================================================

    def service_popup(self):
        self.ui.services_popup.setFixedWidth(1381)  
        self.ui.services_widget.setFixedWidth(701)  
        self.ui.home.setStyleSheet("background-color: none") 
        self.ui.mem_list.setStyleSheet("background-color: none")
        self.ui.mem_status.setStyleSheet("background-color: none")
        self.ui.transaction.setStyleSheet("background-color: none")
        self.ui.services.setStyleSheet("background-color: rgba(255,255,255,50)")
        self.ui.employees.setStyleSheet("background-color: none")

    def close_service_popup(self):
        self.ui.services_popup.setFixedWidth(0)  
        self.ui.services_widget.setFixedWidth(0)  
        self.ui.services.setStyleSheet("background-color: none")
        if self.prev_page == 1: self.select_home()
        elif self.prev_page == 2: self.select_memlist()
        elif self.prev_page == 3: self.select_memstat()
        elif self.prev_page == 4: self.select_transact()
        elif self.prev_page == 5: self.select_employees()

    def add_service(self):
        self.ui.services_widget.setFixedWidth(0)  
        self.ui.add_service_widget.setFixedWidth(701)  

    def cancel_add_service(self):
        self.ui.services_widget.setFixedWidth(701)  
        self.ui.add_service_widget.setFixedWidth(0)  
    
    def edit_service(self):
        self.ui.services_widget.setFixedWidth(0)  
        self.ui.update_service_widget.setFixedWidth(701)  

    def cancel_edit_service(self):
        self.ui.services_widget.setFixedWidth(701)  
        self.ui.update_service_widget.setFixedWidth(0)  
        
    #Logout confirmation
    # ===========================================================================================================================================================================

    def logoutpopup(self):
        self.ui.logout_popup.setFixedWidth(1381)

    def confirm_logout(self):
        self.close()
        self.login_window = LoginWindow()
        self.login_window.show()

    def cancel_logout(self):
        self.ui.logout_popup.setFixedWidth(0)

    #Membership renewal 
    # ===========================================================================================================================================================================

    def renew_popup(self):
        self.ui.renew_popup.setFixedWidth(1381)

    def cancel_renew(self):
        self.ui.renew_popup.setFixedWidth(0)

    def pay_renew(self):
        pass

    # List of member functions 
    # ===========================================================================================================================================================================

    def add_member(self):
        self.ui.register_popup.setFixedWidth(1381)

    def regis_cancel(self):
        self.ui.register_popup.setFixedWidth(0)

    def regis_save(self):
        self.ui.payment_popup.setFixedWidth(1381)
        self.ui.register_popup.setFixedWidth(0)

    def cancel_payment(self):
        self.ui.payment_popup.setFixedWidth(0)
        self.ui.register_popup.setFixedWidth(1381)

    def confirm_payment(self):
        pass

    def delete_member(self):
        self.ui.member_delete_popup.setFixedWidth(1381)
    
    def cancel_delete_mem(self):
        self.ui.member_delete_popup.setFixedWidth(0)

    def confirm_delete_mem(self):
        pass

    def edit_member(self):
        self.ui.edit_details_popup.setFixedWidth(1381)

    def cancel_edit_mem(self):
        self.ui.edit_details_popup.setFixedWidth(0)

    def save_edit_mem(self):
        pass
    
    #Employee menu functions
    # ===========================================================================================================================================================================
    def add_employee(self):
        self.ui.add_employee_popup.setFixedWidth(1381)
    
    def cancel_add_employee(self):
        self.ui.add_employee_popup.setFixedWidth(0)

    def edit_employee(self):
        self.ui.edit_employee_popup.setFixedWidth(1381)
    
    def cancel_edit_employee(self):
        self.ui.edit_employee_popup.setFixedWidth(0)



if __name__ == '__main__':
    app = QtWidgets.QApplication([])
    connect()
    login = MainWindow()
    app.exec()
    

