from PySide6 import QtWidgets, QtCore
from ui_loginUI import *
from ui_mainUI import *
from config import config
import psycopg2
import time


#db connection
def connect():
    connection = None
    try:
        params = config()
        print('Connecting...')
        connection = psycopg2.connect(**params)

        #create cursor

        crsr = connection.cursor()
        print('PostgreSQL database version: ')
        crsr.execute('SELECT version()')
        db_version = crsr.fetchone()
        print(db_version)
        crsr.close()
    except(Exception, psycopg2.DataError) as error:
        print(error)
    finally:
        if connection is not None:
            connection.close()
            print('DB connection terminated.')



class LoginWindow(QtWidgets.QMainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        self.ui = Ui_LoginWindow()
        self.ui.setupUi(self)
        self.show()

        #LOGIN 
        # ===========================================================================================================================================================================
        
        self.ui.signInBtn.clicked.connect(self.handle_login)
        self.ui.usernameField.installEventFilter(self)
        self.ui.passwordField.installEventFilter(self)

    #Enter key clicked
    # ===========================================================================================================================================================================

    def eventFilter(self, source, event):
        if event.type() == QtCore.QEvent.KeyPress:
            if source == self.ui.usernameField or source == self.ui.passwordField:
                key = event.key()
                if key == QtCore.Qt.Key_Return or key == QtCore.Qt.Key_Enter:
                    self.handle_login()
                else:
                    self.ui.usernameField.setStyleSheet("border: none;")
                    self.ui.passwordField.setStyleSheet("border: none;")

    #Login button key clicked
    # ===========================================================================================================================================================================
    
    def handle_login(self):
        if self.ui.usernameField.text() == 'admin' and self.ui.passwordField.text() == 'adminpass':
            self.close()
            self.main_window = MainWindow()
     
        else:
            self.ui.usernameField.setStyleSheet("border: 1px solid red;")
            self.ui.passwordField.setStyleSheet("border: 1px solid red;")
            

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.show()
        self.prev_page = 1
        
        #TABLE WIDGETS
        # ===========================================================================================================================================================================

        self.ui.mem_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ui.memStat_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ui.transac_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ui.services_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ui.emp_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        
        #remove vertical headers
        self.ui.emp_table.verticalHeader().setVisible(False)
        self.ui.transac_table.verticalHeader().setVisible(False)
        self.ui.memStat_table.verticalHeader().setVisible(False)
        self.ui.mem_table.verticalHeader().setVisible(False)
        self.ui.services_table.verticalHeader().setVisible(False)

        #MENU
        # ===========================================================================================================================================================================

        self.ui.menu_container.setCurrentWidget(self.ui.home_page)
        self.ui.home.setStyleSheet("background-color: rgba(255,255,255,50)")
        self.ui.home.clicked.connect(self.select_home)
        self.ui.mem_list.clicked.connect(self.select_memlist)
        self.ui.mem_status.clicked.connect(self.select_memstat)
        self.ui.transaction.clicked.connect(self.select_transact)
        self.ui.employees.clicked.connect(self.select_employees)
        self.ui.services.clicked.connect(self.service_popup)

        #LOGOUT 
        # ===========================================================================================================================================================================

        self.ui.services_exitbtn.clicked.connect(self.close_service_popup)
        self.ui.logout.clicked.connect(self.logoutpopup)
        self.ui.confLogout_btn.clicked.connect(self.confirm_logout)
        self.ui.cancelLogout_btn.clicked.connect(self.cancel_logout)

        #SERVICES 
        # ===========================================================================================================================================================================

        self.ui.addService_btn.clicked.connect(self.add_service)
        self.ui.addService_cancelbtn.clicked.connect(self.cancel_add_service)
        self.ui.editService_btn.clicked.connect(self.edit_service)
        self.ui.serviceUpdate_cancelbtn.clicked.connect(self.cancel_edit_service)
        self.ui.addService_savebtn.clicked.connect(self.add_service_into_DB)
        self.ui.serviceUpdate_savebtn.clicked.connect(self.update_service)

        
        #RENEW MEMBERSHIP SERVICE
        # ===========================================================================================================================================================================

        self.ui.renew_btn.clicked.connect(self.renew_popup)
        self.ui.renewCancel_btn.clicked.connect(self.cancel_renew)
        self.ui.renewPay_btn.clicked.connect(self.pay_renew)

        #REGISTER MEMBER
        # ===========================================================================================================================================================================

        self.ui.add_member.clicked.connect(self.add_member)
        self.ui.regismem_cancelbtn.clicked.connect(self.regis_cancel)
        self.ui.regismem_savebtn.clicked.connect(self.regis_save)
        self.ui.pay_cancelbtn.clicked.connect(self.cancel_payment)
        #self.ui.pay_btn.clicked.connect(self.confirm_payment)
        self.ui.pay_btn.clicked.connect(self.add_member_into_DB)
        self.retrieve_services_from_DB()
        self.retrieve_employee_from_DB()
        self.ui.paymentServices_cmbBox.currentTextChanged.connect(self.update_payment_amount)


        #DELETE MEMBER
        # ===========================================================================================================================================================================

        self.ui.delete_member.clicked.connect(self.delete_member)
        self.ui.cancelDelete_mem.clicked.connect(self.cancel_delete_mem)
        self.ui.confDelete_mem.clicked.connect(self.confirm_delete_mem)

        #EDIT MEMBER DETAILS
        # ===========================================================================================================================================================================
        
        self.ui.edit_member.clicked.connect(self.edit_member)
        self.ui.mem_cancelbtn.clicked.connect(self.cancel_edit_mem)
        self.ui.mem_savebtn.clicked.connect(self.save_edit_mem)

        #EMPLOYEE
        # ===========================================================================================================================================================================

        self.ui.add_employee.clicked.connect(self.add_employee)
        self.ui.AddEmp_cancelbtn.clicked.connect(self.cancel_add_employee)
        self.ui.edit_employee.clicked.connect(self.edit_employee)
        self.ui.EditEmp_cancelbtn.clicked.connect(self.cancel_edit_employee)
        self.ui.AddEmp_savebtn.clicked.connect(self.add_employee_into_DB)
        self.ui.EditEmp_savebtn.clicked.connect(self.update_emp_details)

    #Menu bar selection
    # ===========================================================================================================================================================================

    def select_home(self):
        self.ui.menu_container.setCurrentWidget(self.ui.home_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.previous(1)
        
    def select_memlist(self):
        self.ui.menu_container.setCurrentWidget(self.ui.member_list_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.previous(2)
        self.populate_mem_table()
        
    def select_memstat(self):
        self.ui.menu_container.setCurrentWidget(self.ui.member_status_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.previous(3)
    
    def select_transact(self):
        self.ui.menu_container.setCurrentWidget(self.ui.transaction_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.previous(4)
    
    def select_employees(self):
        self.ui.menu_container.setCurrentWidget(self.ui.employees_page)
        self.ui.home.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_list.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.mem_status.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.transaction.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.services.setStyleSheet("QPushButton{background-color: none} QPushButton:hover{background-color: rgba(255,255,255,50);}")
        self.ui.employees.setStyleSheet("QPushButton{background-color: rgba(255,255,255,50)}")
        self.previous(5)
        self.populate_employee_table()

    #Previous Page
    # ===========================================================================================================================================================================

    def previous(self,page):
        self.prev_page = page

    #Show list of services
    # ===========================================================================================================================================================================

    def service_popup(self):
        self.ui.services_popup.setFixedWidth(1381)  
        self.ui.home.setStyleSheet("background-color: none") 
        self.ui.mem_list.setStyleSheet("background-color: none")
        self.ui.mem_status.setStyleSheet("background-color: none")
        self.ui.transaction.setStyleSheet("background-color: none")
        self.ui.services.setStyleSheet("background-color: rgba(255,255,255,50)")
        self.ui.employees.setStyleSheet("background-color: none")
        self.populate_services_table()
        

    def close_service_popup(self):
        self.ui.services_popup.setFixedWidth(0)   
        self.ui.services.setStyleSheet("background-color: none")
        if self.prev_page == 1: self.select_home()
        elif self.prev_page == 2: self.select_memlist()
        elif self.prev_page == 3: self.select_memstat()
        elif self.prev_page == 4: self.select_transact()
        elif self.prev_page == 5: self.select_employees()

    def add_service(self):
        self.ui.services_widget.setFixedWidth(0)  
        self.ui.add_service_widget.setFixedWidth(701)  

    def cancel_add_service(self):
        self.ui.services_widget.setFixedWidth(701)  
        self.ui.add_service_widget.setFixedWidth(0)  
        self.ui.addService_name.setText('')
        self.ui.addService_amount.setText('')
    
    def edit_service(self):
        self.ui.services_widget.setFixedWidth(0)  
        self.ui.update_service_widget.setFixedWidth(701)  

        selected_row = self.ui.services_table.currentRow()
        if selected_row != -1:
            service_id = self.ui.services_table.item(selected_row, 0)
            conn = None
            try:
                params = config()
                conn = psycopg2.connect(**params)

                cursor = conn.cursor()
                cursor.execute("SELECT SERV_TYPE, SERV_PRICE FROM SERVICE WHERE SERV_ID = '" + service_id.text() +"';")
                service = cursor.fetchone()

                if service:
                    serv_type, serv_price = service
                    self.ui.service_Update.setText(str(serv_type))
                    self.ui.service_Amount.setText(str(serv_price))

                else:
                    print("No service found for SERV_ID:", service_id.text())


            except (Exception, psycopg2.Error) as error:
                print("Error retrieving services from the database:", error)

            finally:
                # Close the cursor and database connection
                if conn is not None:
                    conn.close()
        else:
             #DAPAT MO ERROR MESSAGE DIRI NA NEED SHA MO SELECT UG ROW FIRST
             print("No row selected.")


    def update_service(self):
        serv_id = self.ui.services_table.item(self.ui.services_table.currentRow(), 0)

        serv_type = self.ui.service_Update.text()
        serv_price = float(self.ui.service_Amount.text())

        sql = "UPDATE SERVICE SET SERV_TYPE = %s, SERV_PRICE = %s WHERE SERV_ID = %s;"
        values = (serv_type, serv_price, serv_id.text())
        conn = None
        try:
            params = config()
            conn = psycopg2.connect(**params)
            cursor = conn.cursor()
            cursor.execute(sql, values)
            conn.commit()
            print("Service details updated successfully.")
            self.ui.services_widget.setFixedWidth(701)
            self.ui.update_service_widget.setFixedWidth(0) 
            self.ui.service_Update.setText('')
            self.ui.service_Amount.setText('')
            self.populate_services_table()

        except (Exception, psycopg2.Error) as error:
            print("Error updating employee details:", error)

        finally:
            if conn is not None:
                conn.close()
        

    def cancel_edit_service(self):
        self.ui.services_widget.setFixedWidth(701)  
        self.ui.update_service_widget.setFixedWidth(0)  
      

    def add_service_into_DB(self):
        serv_type = self.ui.addService_name.text()
        serv_price = float(self.ui.addService_amount.text())
        sql = "INSERT INTO SERVICE (SERV_TYPE, SERV_PRICE) VALUES(%s, %s);"
        values = (serv_type, serv_price)

        conn = None
        try:
            params = config()
            conn = psycopg2.connect(**params)

            cur= conn.cursor()
            cur.execute(sql, values)
            conn.commit()
            cur.close
            
        except(Exception, psycopg2.DataError) as error:
            print(error)
        finally:
            if conn is not None:
                conn.close()
                self.ui.success_widget.setFixedWidth(371)
                QtCore.QTimer.singleShot(1300, lambda: self.ui.success_widget.setFixedWidth(0))   
                

        
        #clears text fields
        self.ui.addService_name.setText('')
        self.ui.addService_amount.setText('')
        self.populate_services_table()

    def populate_services_table(self):
        conn = None
        try:
            params = config()
            conn = psycopg2.connect(**params)

            sql = "SELECT * FROM SERVICE"
            cursor = conn.cursor()
            cursor.execute(sql)
            result = cursor.fetchall()
            
            self.ui.services_table.setRowCount(0)

            for row_number, row_data in enumerate(result):
                self.ui.services_table.insertRow(row_number)
                for column_number, data in enumerate(row_data):
                    item = QtWidgets.QTableWidgetItem(str(data))
                    item.setTextAlignment(Qt.AlignHCenter)
                    self.ui.services_table.setItem(row_number, column_number, item)
            
        except (Exception, psycopg2.Error) as error:
            print("Error retrieving data from the database:", error)
        
        finally:
            if conn is not None:
                conn.close()
        
    def retrieve_services_from_DB(self):
        conn = None
        try:
            params = config()
            conn = psycopg2.connect(**params)

            cursor = conn.cursor()
            cursor.execute("SELECT SERV_TYPE FROM SERVICE")
            services = cursor.fetchall()
            self.ui.paymentServices_cmbBox.clear()

            self.ui.paymentServices_cmbBox.addItem('Service')
            for service in services:
                service_type = service[0]
                self.ui.paymentServices_cmbBox.addItem(service_type)

        except (Exception, psycopg2.Error) as error:
            print("Error retrieving services from the database:", error)

        finally:
            # Close the cursor and database connection
            if conn is not None:
                conn.close()

    
    #Logout confirmation
    # ===========================================================================================================================================================================

    def logoutpopup(self):
        self.ui.logout_popup.setFixedWidth(1381)

    def confirm_logout(self):
        self.close()
        self.login_window = LoginWindow()
        self.login_window.show()

    def cancel_logout(self):
        self.ui.logout_popup.setFixedWidth(0)

    #Membership renewal 
    # ===========================================================================================================================================================================

    def renew_popup(self):
        self.ui.renew_popup.setFixedWidth(1381)

    def cancel_renew(self):
        self.ui.renew_popup.setFixedWidth(0)

    def pay_renew(self):
        pass

    # List of member functions 
    # ===========================================================================================================================================================================

    def add_member(self):
        self.ui.register_popup.setFixedWidth(1381)

    def regis_cancel(self):
        self.ui.register_popup.setFixedWidth(0)

    def regis_save(self):
        self.ui.payment_popup.setFixedWidth(1381)
        self.ui.register_popup.setFixedWidth(0)

    def cancel_payment(self):
        self.ui.payment_popup.setFixedWidth(0)
        self.ui.register_popup.setFixedWidth(1381)

    def confirm_payment(self):
        pass

    def delete_member(self):
        self.ui.member_delete_popup.setFixedWidth(1381)
    
    def cancel_delete_mem(self):
        self.ui.member_delete_popup.setFixedWidth(0)

    def confirm_delete_mem(self):
        pass

    def edit_member(self):
        self.ui.edit_details_popup.setFixedWidth(1381)

    def cancel_edit_mem(self):
        self.ui.edit_details_popup.setFixedWidth(0)

    def save_edit_mem(self):
        pass

    def update_payment_amount(self):
        servicename = self.ui.paymentServices_cmbBox.currentText()
        service_id, serv_price = self.get_service_id(servicename)

        if serv_price is not None:
            self.ui.payment_amt.setText(str(serv_price))
        else:
            self.ui.payment_amt.setText('')  




    def get_selected_radio_button(self):
        selected_radio_button = None
        if self.ui.regismemProf_radio.isChecked():
            selected_radio_button = "Professional"
        elif self.ui.regismemStud_radio.isChecked():
            selected_radio_button = "Student"
        else:
            selected_radio_button = "None"

        return selected_radio_button

    def get_service_id(self, servicename):
        try:
            params = config()
            conn = psycopg2.connect(**params)
            cursor = conn.cursor()

            cursor.execute("SELECT SERV_ID, SERV_PRICE FROM SERVICE WHERE SERV_TYPE = %s;", (servicename,))
            service = cursor.fetchone() 

            if service:
                serv_id, serv_price = service  
                return serv_id, serv_price
            else:
                print("Service not found:", servicename)
                return None, None

        except (Exception, psycopg2.Error) as error:
            print("Error retrieving service from the database:", error)
            return None, None
        finally:
            if conn is not None:
                conn.close()


    def get_emp_id(self):
        emp_name = self.ui.payment_instructor.currentText()
        try:
            params = config()
            conn = psycopg2.connect(**params)
            cursor = conn.cursor()
            cursor.execute("SELECT EMP_ID FROM EMPLOYEE WHERE EMP_NAME = %s;", (emp_name,))
            emp = cursor.fetchone()

            if emp:
                employee = emp[0]
                return employee
            else:
                print('Employee not found')
                return None
        except (Exception, psycopg2.Error) as error:
            print('Error retrieving employee from the database: ', error)
            return None
        finally:
            if conn is not None:
                conn.close()


    def populate_mem_table(self):
        conn = None
        try:
            params = config()
            conn = psycopg2.connect(**params)

            sql = "SELECT MEM_ID, MEM_NAME, MEM_BIRTHDATE, MEM_GENDER, MEM_ADDRESS FROM MEMBERS"
            cursor = conn.cursor()
            cursor.execute(sql)
            result = cursor.fetchall()
            
            self.ui.mem_table.setRowCount(0)

            for row_number, row_data in enumerate(result):
                self.ui.mem_table.insertRow(row_number)
                for column_number, data in enumerate(row_data):
                    self.ui.mem_table.setItem(row_number, column_number, QtWidgets.QTableWidgetItem(str(data)))
            
        except (Exception, psycopg2.Error) as error:
            print("Error retrieving data from the database:", error)
        
        finally:
            if conn is not None:
                conn.close()
        
    def add_member_into_DB(self):
        mem_name = self.ui.regismem_name.text()
        mem_address = self.ui.regismem_address.text()
        mem_DOB = self.ui.regismem_DOB.date().toString('yyyy-MM-dd')
        mem_contact = self.ui.regismem_contact.text()
        mem_medical = self.ui.regismem_medicAilment.text()
        mem_prevGym = self.ui.regismem_prevGym.text()
        mem_BP = self.ui.regismem_BP.text()
        mem_stat = self.ui.regismem_Status.currentText()
        mem_act = self.ui.regismem_physicalAct.text()
        mem_weight = float(self.ui.regismem_weight.text())
        mem_height = float(self.ui.regismem_height.text())
        mem_gender = self.ui.registermem_Gender.currentText()
        mem_type = self.get_selected_radio_button() 
        servicename = self.ui.paymentServices_cmbBox.currentText()
        service_id ,serv_price= self.get_service_id(servicename)
        employee = self.get_emp_id()

        sql = "INSERT INTO MEMBERS(MEM_NAME, MEM_BIRTHDATE, MEM_ADDRESS, MEM_TELEPHONE, MEM_PHYSICAL_ACT, MEM_MED_AILMENT, MEM_WEIGHT, MEM_HEIGHT, MEM_BP, MEM_GENDER, MEM_STATUS, MEM_TYPE, MEM_PREV_GYM, SERV_ID, EMP_ID) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        values = (mem_name, mem_DOB, mem_address, mem_contact, mem_act, mem_medical, mem_weight, mem_height, mem_BP, mem_gender, mem_stat, mem_type, mem_prevGym, service_id, employee)

        conn = None

        try:
            params = config()
            conn = psycopg2.connect(**params)

            cur= conn.cursor()
            cur.execute(sql, (mem_name, mem_DOB, mem_address, mem_contact, mem_act, mem_medical, mem_weight, mem_height, mem_BP, mem_gender, mem_stat, mem_type, mem_prevGym, service_id, employee))
            conn.commit()
            cur.close

        except(Exception, psycopg2.DataError) as error:
            print(error)
        finally:
            if conn is not None:
                conn.close()

        self.ui.regismem_name.setText('')
        self.ui.regismem_DOB.setDate(QDate(1900, 1, 1))
        self.ui.regismem_address.setText('')
        self.ui.regismem_contact.setText('')
        self.ui.regismem_physicalAct.setText('')
        self.ui.regismem_medicAilment.setText('')
        self.ui.regismem_weight.setText('')
        self.ui.regismem_height.setText('')
        self.ui.regismem_BP.setText('')
        self.ui.registermem_Gender.setCurrentText('Gender')
        self.ui.regismem_Status.setCurrentText('Status')
        self.ui.regismemStud_radio.setChecked(False)
        self.ui.regismemProf_radio.setChecked(False)
        self.ui.regismem_prevGym.setText('')
        self.ui.payment_instructor.setCurrentText('Instructor')
        self.ui.paymentServices_cmbBox.setCurrentText('Services')
        self.ui.payment_tenderedAmt.setText('')
        self.ui.payment_amt.setText('')
        self.ui.payment_change.setText('')   
        self.populate_mem_table()


    #Employee menu functions
    # ===========================================================================================================================================================================
    def add_employee(self):
        self.ui.add_employee_popup.setFixedWidth(1381)
    
    def cancel_add_employee(self):
        self.ui.add_employee_popup.setFixedWidth(0)
        self.ui.AddEmp_contact.setText('')
        self.ui.AddEmp_name.setText('')
        self.ui.AddEmp_address.setText('')
        self.ui.AddEmp_position.setCurrentText('')
        self.ui.AddEmp_DOB.setDate(QDate(1900, 1, 1))

    def edit_employee(self):
        self.ui.edit_employee_popup.setFixedWidth(1381)

        selected_row = self.ui.emp_table.currentRow()
        if selected_row != -1:
            emp_id = self.ui.emp_table.item(selected_row, 0)
            conn = None
            try:
                params = config()
                conn = psycopg2.connect(**params)

                cursor = conn.cursor()
                cursor.execute("SELECT EMP_NAME, EMP_ADDRESS, EMP_BIRTHDATE, EMP_CONTACT_NUM, EMP_POSITION FROM EMPLOYEE WHERE EMP_ID = '" + emp_id.text() +"';")
                employee_data = cursor.fetchone()

                if employee_data:
                    emp_name, emp_address, emp_birthdate, emp_contact_num, emp_position = employee_data
                    self.ui.editEmp_name.setText(str(emp_name))
                    self.ui.editEmp_address.setText(str(emp_address))
                    self.ui.editEmp_DOB.setDate(QDate(emp_birthdate))
                    self.ui.editEmp_contact.setText(str(emp_contact_num))
                    self.ui.editEmp_position.setCurrentText(str(emp_position))

                else:
                    print("No service found for SERV_ID:", emp_id.text())


            except (Exception, psycopg2.Error) as error:
                print("Error retrieving services from the database:", error)

            finally:
                # Close the cursor and database connection
                if conn is not None:
                    conn.close()
        else:
             #DAPAT MO ERROR MESSAGE DIRI NA NEED SHA MO SELECT UG ROW FIRST
             print("No row selected.")

    def retrieve_employee_from_DB(self):
        conn = None
        try:
            params = config()
            conn = psycopg2.connect(**params)

            cursor = conn.cursor()
            cursor.execute("SELECT EMP_NAME FROM EMPLOYEE WHERE EMP_POSITION = '" + 'Instructor' + "';")
            employees = cursor.fetchall()
            self.ui.payment_instructor.clear()

            self.ui.payment_instructor.addItem('Instructor')
            for employee in employees:
                emp_name = employee[0]
                self.ui.payment_instructor.addItem(emp_name)

        except (Exception, psycopg2.Error) as error:
            print("Error retrieving services from the database:", error)

        finally:
            # Close the cursor and database connection
            if conn is not None:
                conn.close()


    def update_emp_details(self):
        emp_id = self.ui.emp_table.item(self.ui.emp_table.currentRow(), 0)

        updateEmp_name = self.ui.editEmp_name.text()
        updateEmp_address = self.ui.editEmp_address.text()
        updateEmp_DOB = self.ui.editEmp_DOB.date().toString('yyyy-MM-dd')
        updateEmp_contact = self.ui.editEmp_contact.text()
        updateEmp_position = self.ui.editEmp_position.currentText()

        sql = "UPDATE EMPLOYEE SET EMP_NAME = %s, EMP_ADDRESS = %s, EMP_BIRTHDATE = %s, EMP_CONTACT_NUM = %s, EMP_POSITION = %s WHERE EMP_ID = %s;"
        values = (updateEmp_name, updateEmp_address, updateEmp_DOB, updateEmp_contact, updateEmp_position, emp_id.text())
        conn = None
        try:
            params = config()
            conn = psycopg2.connect(**params)
            cursor = conn.cursor()
            cursor.execute(sql, values)
            conn.commit()
            print("Employee details updated successfully.")
            self.ui.edit_employee_popup.setFixedWidth(0)
            self.ui.editEmp_name.setText('')
            self.ui.editEmp_address.setText('')
            self.ui.editEmp_contact.setText('')
            self.ui.editEmp_DOB.setDate(QDate(1900, 1, 1))
            self.ui.editEmp_position.setCurrentText('')
            self.populate_employee_table()

        except (Exception, psycopg2.Error) as error:
            print("Error updating employee details:", error)

        finally:
            if conn is not None:
                conn.close()
    
    def cancel_edit_employee(self):
        self.ui.edit_employee_popup.setFixedWidth(0)
        self.ui.editEmp_name.setText('')
        self.ui.editEmp_address.setText('')
        self.ui.editEmp_contact.setText('')
        self.ui.editEmp_DOB.setDate(QDate(1900, 1, 1))
        self.ui.editEmp_position.setCurrentText('')

    def populate_employee_table(self):
        conn = None
        try:
            params = config()
            conn = psycopg2.connect(**params)

            sql = "SELECT EMP_ID, EMP_NAME, EMP_CONTACT_NUM, EMP_ADDRESS, EMP_POSITION FROM EMPLOYEE"
            cursor = conn.cursor()
            cursor.execute(sql)
            result = cursor.fetchall()
            
            self.ui.emp_table.setRowCount(0)

            for row_number, row_data in enumerate(result):
                self.ui.emp_table.insertRow(row_number)
                for column_number, data in enumerate(row_data):
                    self.ui.emp_table.setItem(row_number, column_number, QtWidgets.QTableWidgetItem(str(data)))
            
        except (Exception, psycopg2.Error) as error:
            print("Error retrieving data from the database:", error)
        
        finally:
            if conn is not None:
                conn.close()

    def add_employee_into_DB(self):
        emp_name = self.ui.AddEmp_name.text()
        emp_address = self.ui.AddEmp_address.text()
        emp_contact = self.ui.AddEmp_contact.text()
        emp_position = self.ui.AddEmp_position.currentText()
        emp_DOB = self.ui.AddEmp_DOB.date().toString('yyyy-MM-dd')

        sql = "INSERT INTO EMPLOYEE(EMP_NAME, EMP_ADDRESS, EMP_BIRTHDATE, EMP_CONTACT_NUM, EMP_POSITION) VALUES(%s, %s, %s, %s, %s)"
        values = (emp_name, emp_address, emp_DOB, emp_contact, emp_position)

        conn = None
        try:
            params = config()
            conn = psycopg2.connect(**params)

            cur= conn.cursor()
            cur.execute(sql, (emp_name, emp_address, emp_DOB, emp_contact, emp_position))
            conn.commit()
            cur.close
            
        except(Exception, psycopg2.DataError) as error:
            print(error)
        finally:
            if conn is not None:
                conn.close()

        #clear text fields
        self.ui.AddEmp_contact.setText('')
        self.ui.AddEmp_name.setText('')
        self.ui.AddEmp_address.setText('')
        self.ui.AddEmp_position.setCurrentText('')
        self.ui.AddEmp_DOB.setDate(QDate(1900, 1, 1))
        self.populate_employee_table()


if __name__ == '__main__':
    app = QtWidgets.QApplication([])
    connect()
    login = MainWindow()
    app.exec()
    

